const express = require('express');
const app = express();

var n, i, a, o = null, s = Object.defineProperty, c = Object.getOwnPropertyDescriptor, l = Object.getOwnPropertyNames, u = Object.prototype.hasOwnProperty, d = (n = (r, n) => {
    var i, o = (i = "u" > typeof document && document.currentScript ? document.currentScript.src : void 0,
        function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            e.ready = new Promise((e, t) => {
                c = e,
                    l = t
            }
            );
            var t, r = Object.assign({}, e), n = "";
            "u" > typeof document && document.currentScript && (n = document.currentScript.src),
                i && (n = i),
                n = 0 !== n.indexOf("blob:") ? n.substr(0, n.replace(/[?#].*/, "").lastIndexOf("/") + 1) : "",
                e.print || console.log.bind(console);
            var a = e.printErr || console.error.bind(console);
            Object.assign(e, r),
                r = null,
                e.arguments && e.arguments,
                e.thisProgram && e.thisProgram,
                e.quit && e.quit,
                e.wasmBinary && (d = e.wasmBinary);
            var o = {
                Memory: function (e) {
                    this.buffer = new ArrayBuffer(65536 * e.initial)
                },
                Module: function (e) { },
                Instance: function (e, t) {
                    this.exports = function (e) {
                        for (var t, r = new Uint8Array(123), n = 25; n >= 0; --n)
                            r[48 + n] = 52 + n,
                                r[65 + n] = n,
                                r[97 + n] = 26 + n;
                        function i(e, t, n) {
                            for (var i, a, o = 0, s = t, c = n.length, l = t + (3 * c >> 2) - ("=" == n[c - 2]) - ("=" == n[c - 1]); o < c; o += 4)
                                i = r[n.charCodeAt(o + 1)],
                                    a = r[n.charCodeAt(o + 2)],
                                    e[s++] = r[n.charCodeAt(o)] << 2 | i >> 4,
                                    s < l && (e[s++] = i << 4 | a >> 2),
                                    s < l && (e[s++] = a << 6 | r[n.charCodeAt(o + 3)])
                        }
                        return r[43] = 62,
                            r[47] = 63,
                            function (e) {
                                var r, n = e.a, a = n.a.buffer, o = new Int8Array(a), s = (new Int16Array(a),
                                    new Int32Array(a)), c = new Uint8Array(a), l = (new Uint16Array(a),
                                        new Uint32Array(a)), u = (new Float32Array(a),
                                            new Float64Array(a),
                                            Math.imul), d = Math.abs, f = Math.clz32, h = n.b, g = n.c, b = n.d, p = 68640;
                                function A(e) {
                                    e |= 0;
                                    var t = 0
                                        , r = 0
                                        , n = 0
                                        , i = 0
                                        , a = 0
                                        , o = 0
                                        , u = 0
                                        , d = 0
                                        , h = 0
                                        , g = 0
                                        , b = 0;
                                    p = b = p - 16 | 0;
                                    e: {
                                        t: {
                                            r: {
                                                n: {
                                                    i: {
                                                        a: {
                                                            o: {
                                                                s: {
                                                                    c: {
                                                                        if (e >>> 0 <= 244) {
                                                                            if (3 & (t = (o = s[650]) >>> (r = (u = e >>> 0 < 11 ? 16 : e + 11 & 504) >>> 3 | 0) | 0)) {
                                                                                t = (e = (r = r + ((-1 ^ t) & 1) | 0) << 3) + 2640 | 0,
                                                                                    n = s[e + 2648 >> 2],
                                                                                    e = s[n + 8 >> 2];
                                                                                l: {
                                                                                    if ((0 | t) == (0 | e)) {
                                                                                        s[650] = k(-2, r) & o;
                                                                                        break l
                                                                                    }
                                                                                    s[e + 12 >> 2] = t,
                                                                                        s[t + 8 >> 2] = e
                                                                                }
                                                                                e = n + 8 | 0,
                                                                                    t = r << 3,
                                                                                    s[n + 4 >> 2] = 3 | t,
                                                                                    s[(t = t + n | 0) + 4 >> 2] = 1 | s[t + 4 >> 2];
                                                                                break e
                                                                            }
                                                                            if ((g = s[652]) >>> 0 >= u >>> 0)
                                                                                break c;
                                                                            if (t) {
                                                                                t = (e = (n = y((0 - (e = 2 << r) | e) & t << r)) << 3) + 2640 | 0,
                                                                                    i = s[e + 2648 >> 2],
                                                                                    e = s[i + 8 >> 2];
                                                                                l: {
                                                                                    if ((0 | t) == (0 | e)) {
                                                                                        o = k(-2, n) & o,
                                                                                            s[650] = o;
                                                                                        break l
                                                                                    }
                                                                                    s[e + 12 >> 2] = t,
                                                                                        s[t + 8 >> 2] = e
                                                                                }
                                                                                if (s[i + 4 >> 2] = 3 | u,
                                                                                    r = i + u | 0,
                                                                                    n = (e = n << 3) - u | 0,
                                                                                    s[r + 4 >> 2] = 1 | n,
                                                                                    s[e + i >> 2] = n,
                                                                                    g) {
                                                                                    t = (-8 & g) + 2640 | 0,
                                                                                        a = s[655],
                                                                                        e = 1 << (g >>> 3);
                                                                                    l: {
                                                                                        if (!(e & o)) {
                                                                                            s[650] = e | o,
                                                                                                e = t;
                                                                                            break l
                                                                                        }
                                                                                        e = s[t + 8 >> 2]
                                                                                    }
                                                                                    s[t + 8 >> 2] = a,
                                                                                        s[e + 12 >> 2] = a,
                                                                                        s[a + 12 >> 2] = t,
                                                                                        s[a + 8 >> 2] = e
                                                                                }
                                                                                e = i + 8 | 0,
                                                                                    s[655] = r,
                                                                                    s[652] = n;
                                                                                break e
                                                                            }
                                                                            if (!(h = s[651]))
                                                                                break c;
                                                                            for (r = s[(y(h) << 2) + 2904 >> 2],
                                                                                i = (-8 & s[r + 4 >> 2]) - u | 0,
                                                                                t = r; ;) {
                                                                                if ((e = s[t + 16 >> 2]) || (e = s[t + 20 >> 2])) {
                                                                                    i = (n = (t = (-8 & s[e + 4 >> 2]) - u | 0) >>> 0 < i >>> 0) ? t : i,
                                                                                        r = n ? e : r,
                                                                                        t = e;
                                                                                    continue
                                                                                }
                                                                                break
                                                                            }
                                                                            if (d = s[r + 24 >> 2],
                                                                                (0 | (n = s[r + 12 >> 2])) != (0 | r)) {
                                                                                e = s[r + 8 >> 2],
                                                                                    s[e + 12 >> 2] = n,
                                                                                    s[n + 8 >> 2] = e;
                                                                                break t
                                                                            }
                                                                            if (!(e = s[(t = r + 20 | 0) >> 2])) {
                                                                                if (!(e = s[r + 16 >> 2]))
                                                                                    break s;
                                                                                t = r + 16 | 0
                                                                            }
                                                                            for (; a = t,
                                                                                n = e,
                                                                                !(!(e = s[(t = e + 20 | 0) >> 2]) && (t = n + 16 | 0,
                                                                                    !(e = s[n + 16 >> 2])));)
                                                                                ;
                                                                            s[a >> 2] = 0;
                                                                            break t
                                                                        }
                                                                        if (u = -1,
                                                                            e >>> 0 > 4294967231 || (u = -8 & (e = e + 11 | 0),
                                                                                !(h = s[651])))
                                                                            break c;
                                                                        i = 0 - u | 0,
                                                                            o = 0,
                                                                            u >>> 0 < 256 || (o = 31,
                                                                                u >>> 0 > 16777215) || (o = ((u >>> 38 - (e = f(e >>> 8 | 0)) & 1) - (e << 1) | 0) + 62 | 0),
                                                                            t = s[(o << 2) + 2904 >> 2];
                                                                        l: {
                                                                            u: {
                                                                                d: {
                                                                                    if (!t) {
                                                                                        e = 0;
                                                                                        break d
                                                                                    }
                                                                                    for (e = 0,
                                                                                        r = u << ((0 | o) != 31 ? 25 - (o >>> 1 | 0) | 0 : 0); ;) {
                                                                                        if (!((a = (-8 & s[t + 4 >> 2]) - u | 0) >>> 0 >= i >>> 0) && (n = t,
                                                                                            !(i = a))) {
                                                                                            i = 0,
                                                                                                e = t;
                                                                                            break u
                                                                                        }
                                                                                        if (a = s[t + 20 >> 2],
                                                                                            t = s[((r >>> 29 & 4) + t | 0) + 16 >> 2],
                                                                                            e = a ? (0 | a) == (0 | t) ? e : a : e,
                                                                                            r <<= 1,
                                                                                            !t)
                                                                                            break
                                                                                    }
                                                                                }
                                                                                if (!(e | n)) {
                                                                                    if (n = 0,
                                                                                        !(e = (0 - (e = 2 << o) | e) & h))
                                                                                        break c;
                                                                                    e = s[(y(e) << 2) + 2904 >> 2]
                                                                                }
                                                                                if (!e)
                                                                                    break l
                                                                            }
                                                                            for (; i = (r = (t = (-8 & s[e + 4 >> 2]) - u | 0) >>> 0 < i >>> 0) ? t : i,
                                                                                n = r ? e : n,
                                                                                e = (t = s[e + 16 >> 2]) ? t : s[e + 20 >> 2];)
                                                                                ;
                                                                        }
                                                                        if (!n | s[652] - u >>> 0 <= i >>> 0)
                                                                            break c;
                                                                        if (o = s[n + 24 >> 2],
                                                                            r = s[n + 12 >> 2],
                                                                            (0 | n) != (0 | r)) {
                                                                            e = s[n + 8 >> 2],
                                                                                s[e + 12 >> 2] = r,
                                                                                s[r + 8 >> 2] = e;
                                                                            break r
                                                                        }
                                                                        if (!(e = s[(t = n + 20 | 0) >> 2])) {
                                                                            if (!(e = s[n + 16 >> 2]))
                                                                                break o;
                                                                            t = n + 16 | 0
                                                                        }
                                                                        for (; a = t,
                                                                            r = e,
                                                                            !(!(e = s[(t = e + 20 | 0) >> 2]) && (t = r + 16 | 0,
                                                                                !(e = s[r + 16 >> 2])));)
                                                                            ;
                                                                        s[a >> 2] = 0;
                                                                        break r
                                                                    }
                                                                    if ((e = s[652]) >>> 0 >= u >>> 0) {
                                                                        n = s[655],
                                                                            t = e - u | 0;
                                                                        c: {
                                                                            if (t >>> 0 >= 16) {
                                                                                s[(r = n + u | 0) + 4 >> 2] = 1 | t,
                                                                                    s[e + n >> 2] = t,
                                                                                    s[n + 4 >> 2] = 3 | u;
                                                                                break c
                                                                            }
                                                                            s[n + 4 >> 2] = 3 | e,
                                                                                s[(e = e + n | 0) + 4 >> 2] = 1 | s[e + 4 >> 2],
                                                                                r = 0,
                                                                                t = 0
                                                                        }
                                                                        s[652] = t,
                                                                            s[655] = r,
                                                                            e = n + 8 | 0;
                                                                        break e
                                                                    }
                                                                    if ((d = s[653]) >>> 0 > u >>> 0) {
                                                                        t = d - u | 0,
                                                                            s[653] = t,
                                                                            e = (r = s[656]) + u | 0,
                                                                            s[656] = e,
                                                                            s[e + 4 >> 2] = 1 | t,
                                                                            s[r + 4 >> 2] = 3 | u,
                                                                            e = r + 8 | 0;
                                                                        break e
                                                                    }
                                                                    if (e = 0,
                                                                        i = u + 47 | 0,
                                                                        s[768] ? r = s[770] : (s[771] = -1,
                                                                            s[772] = -1,
                                                                            s[769] = 4096,
                                                                            s[770] = 4096,
                                                                            s[768] = b + 12 & -16 ^ 1431655768,
                                                                            s[773] = 0,
                                                                            s[761] = 0,
                                                                            r = 4096),
                                                                        (t = (o = i + r | 0) & (a = 0 - r | 0)) >>> 0 <= u >>> 0 || (n = s[760]) && n >>> 0 < (h = (r = s[758]) + t | 0) >>> 0 | r >>> 0 >= h >>> 0)
                                                                        break e;
                                                                    c: {
                                                                        if (!(4 & c[3044])) {
                                                                            l: {
                                                                                u: {
                                                                                    d: {
                                                                                        f: {
                                                                                            if (n = s[656])
                                                                                                for (e = 3048; ;) {
                                                                                                    if ((r = s[e >> 2]) >>> 0 <= n >>> 0 & n >>> 0 < r + s[e + 4 >> 2] >>> 0)
                                                                                                        break f;
                                                                                                    if (!(e = s[e + 8 >> 2]))
                                                                                                        break
                                                                                                }
                                                                                            if ((0 | (r = v(0))) == -1 || (o = t,
                                                                                                (e = (n = s[769]) - 1 | 0) & r && (o = (t - r | 0) + (e + r & 0 - n) | 0),
                                                                                                o >>> 0 <= u >>> 0) || (n = s[760]) && n >>> 0 < (a = (e = s[758]) + o | 0) >>> 0 | e >>> 0 >= a >>> 0)
                                                                                                break l;
                                                                                            if ((0 | r) != (0 | (e = v(o))))
                                                                                                break d;
                                                                                            break c
                                                                                        }
                                                                                        if ((0 | (r = v(o = a & o - d))) == (s[e >> 2] + s[e + 4 >> 2] | 0))
                                                                                            break u;
                                                                                        e = r
                                                                                    }
                                                                                    if ((0 | e) == -1)
                                                                                        break l;
                                                                                    if (u + 48 >>> 0 <= o >>> 0) {
                                                                                        r = e;
                                                                                        break c
                                                                                    }
                                                                                    if ((0 | v(r = (r = s[770]) + (i - o | 0) & 0 - r)) == -1)
                                                                                        break l;
                                                                                    o = r + o | 0,
                                                                                        r = e;
                                                                                    break c
                                                                                }
                                                                                if ((0 | r) != -1)
                                                                                    break c
                                                                            }
                                                                            s[761] = 4 | s[761]
                                                                        }
                                                                        if ((0 | (r = v(t))) == -1 | (0 | (e = v(0))) == -1 | e >>> 0 <= r >>> 0 || (o = e - r | 0) >>> 0 <= u + 40 >>> 0)
                                                                            break n
                                                                    }
                                                                    e = s[758] + o | 0,
                                                                        s[758] = e,
                                                                        e >>> 0 > l[759] && (s[759] = e);
                                                                    c: {
                                                                        if (i = s[656]) {
                                                                            for (e = 3048; ;) {
                                                                                if (((n = s[e >> 2]) + (t = s[e + 4 >> 2]) | 0) == (0 | r))
                                                                                    break c;
                                                                                if (!(e = s[e + 8 >> 2]))
                                                                                    break
                                                                            }
                                                                            break a
                                                                        }
                                                                        for ((e = s[654]) >>> 0 <= r >>> 0 && e || (s[654] = r),
                                                                            e = 0,
                                                                            s[763] = o,
                                                                            s[762] = r,
                                                                            s[658] = -1,
                                                                            s[659] = s[768],
                                                                            s[765] = 0; t = (n = e << 3) + 2640 | 0,
                                                                            s[n + 2648 >> 2] = t,
                                                                            s[n + 2652 >> 2] = t,
                                                                            (0 | (e = e + 1 | 0)) != 32;)
                                                                            ;
                                                                        t = (n = o - 40 | 0) - (e = -8 - r & 7) | 0,
                                                                            s[653] = t,
                                                                            e = e + r | 0,
                                                                            s[656] = e,
                                                                            s[e + 4 >> 2] = 1 | t,
                                                                            s[(r + n | 0) + 4 >> 2] = 40,
                                                                            s[657] = s[772];
                                                                        break i
                                                                    }
                                                                    if (8 & s[e + 12 >> 2] | (r >>> 0 <= i >>> 0 | n >>> 0 > i >>> 0))
                                                                        break a;
                                                                    s[e + 4 >> 2] = t + o,
                                                                        r = (e = -8 - i & 7) + i | 0,
                                                                        s[656] = r,
                                                                        e = (t = s[653] + o | 0) - e | 0,
                                                                        s[653] = e,
                                                                        s[r + 4 >> 2] = 1 | e,
                                                                        s[(t + i | 0) + 4 >> 2] = 40,
                                                                        s[657] = s[772];
                                                                    break i
                                                                }
                                                                n = 0;
                                                                break t
                                                            }
                                                            r = 0;
                                                            break r
                                                        }
                                                        l[654] > r >>> 0 && (s[654] = r),
                                                            t = r + o | 0,
                                                            e = 3048;
                                                        a: {
                                                            o: {
                                                                s: {
                                                                    for (; ;) {
                                                                        if ((0 | t) != s[e >> 2]) {
                                                                            if (e = s[e + 8 >> 2])
                                                                                continue;
                                                                            break s
                                                                        }
                                                                        break
                                                                    }
                                                                    if (!(8 & c[e + 12 | 0]))
                                                                        break o
                                                                }
                                                                for (e = 3048; ;) {
                                                                    if (!((t = s[e >> 2]) >>> 0 <= i >>> 0) || !((a = t + s[e + 4 >> 2] | 0) >>> 0 > i >>> 0)) {
                                                                        e = s[e + 8 >> 2];
                                                                        continue
                                                                    }
                                                                    break
                                                                }
                                                                for (t = (n = o - 40 | 0) - (e = -8 - r & 7) | 0,
                                                                    s[653] = t,
                                                                    e = e + r | 0,
                                                                    s[656] = e,
                                                                    s[e + 4 >> 2] = 1 | t,
                                                                    s[(r + n | 0) + 4 >> 2] = 40,
                                                                    s[657] = s[772],
                                                                    s[(n = (e = (a + (39 - a & 7) | 0) - 47 | 0) >>> 0 < i + 16 >>> 0 ? i : e) + 4 >> 2] = 27,
                                                                    e = s[765],
                                                                    s[n + 16 >> 2] = s[764],
                                                                    s[n + 20 >> 2] = e,
                                                                    e = s[763],
                                                                    s[n + 8 >> 2] = s[762],
                                                                    s[n + 12 >> 2] = e,
                                                                    s[764] = n + 8,
                                                                    s[763] = o,
                                                                    s[762] = r,
                                                                    s[765] = 0,
                                                                    e = n + 24 | 0; s[e + 4 >> 2] = 7,
                                                                    t = e + 8 | 0,
                                                                    e = e + 4 | 0,
                                                                    t >>> 0 < a >>> 0;)
                                                                    ;
                                                                if ((0 | n) == (0 | i))
                                                                    break i;
                                                                if (s[n + 4 >> 2] = -2 & s[n + 4 >> 2],
                                                                    a = n - i | 0,
                                                                    s[i + 4 >> 2] = 1 | a,
                                                                    s[n >> 2] = a,
                                                                    a >>> 0 <= 255) {
                                                                    t = (-8 & a) + 2640 | 0,
                                                                        r = s[650],
                                                                        e = 1 << (a >>> 3);
                                                                    s: {
                                                                        if (!(r & e)) {
                                                                            s[650] = e | r,
                                                                                e = t;
                                                                            break s
                                                                        }
                                                                        e = s[t + 8 >> 2]
                                                                    }
                                                                    s[t + 8 >> 2] = i,
                                                                        s[e + 12 >> 2] = i,
                                                                        s[i + 12 >> 2] = t,
                                                                        s[i + 8 >> 2] = e;
                                                                    break i
                                                                }
                                                                e = 31,
                                                                    a >>> 0 <= 16777215 && (e = f(a >>> 8 | 0),
                                                                        e = ((a >>> 38 - e & 1) - (e << 1) | 0) + 62 | 0),
                                                                    s[i + 28 >> 2] = e,
                                                                    s[i + 16 >> 2] = 0,
                                                                    s[i + 20 >> 2] = 0,
                                                                    t = (e << 2) + 2904 | 0,
                                                                    n = s[651],
                                                                    r = 1 << e;
                                                                s: {
                                                                    if (!(n & r)) {
                                                                        s[651] = r | n,
                                                                            s[t >> 2] = i;
                                                                        break s
                                                                    }
                                                                    for (e = a << ((0 | e) != 31 ? 25 - (e >>> 1 | 0) | 0 : 0),
                                                                        n = s[t >> 2]; ;) {
                                                                        if ((0 | a) == (-8 & s[(t = n) + 4 >> 2]))
                                                                            break a;
                                                                        if (r = e >>> 29 | 0,
                                                                            e <<= 1,
                                                                            !(n = s[(r = (4 & r) + t | 0) + 16 >> 2]))
                                                                            break
                                                                    }
                                                                    s[r + 16 >> 2] = i
                                                                }
                                                                s[i + 24 >> 2] = t,
                                                                    s[i + 12 >> 2] = i,
                                                                    s[i + 8 >> 2] = i;
                                                                break i
                                                            }
                                                            s[e >> 2] = r,
                                                                s[e + 4 >> 2] = s[e + 4 >> 2] + o,
                                                                s[(h = (-8 - r & 7) + r | 0) + 4 >> 2] = 3 | u,
                                                                o = (i = t + (-8 - t & 7) | 0) - (d = u + h | 0) | 0;
                                                            o: {
                                                                if (s[656] == (0 | i)) {
                                                                    s[656] = d,
                                                                        e = s[653] + o | 0,
                                                                        s[653] = e,
                                                                        s[d + 4 >> 2] = 1 | e;
                                                                    break o
                                                                }
                                                                if (s[655] == (0 | i)) {
                                                                    s[655] = d,
                                                                        e = s[652] + o | 0,
                                                                        s[652] = e,
                                                                        s[d + 4 >> 2] = 1 | e,
                                                                        s[e + d >> 2] = e;
                                                                    break o
                                                                }
                                                                if ((3 & (r = s[i + 4 >> 2])) == 1) {
                                                                    a = -8 & r;
                                                                    s: {
                                                                        if (r >>> 0 <= 255) {
                                                                            if ((0 | (t = s[i + 12 >> 2])) == (0 | (e = s[i + 8 >> 2]))) {
                                                                                s[650] = s[650] & k(-2, r >>> 3 | 0);
                                                                                break s
                                                                            }
                                                                            s[e + 12 >> 2] = t,
                                                                                s[t + 8 >> 2] = e;
                                                                            break s
                                                                        }
                                                                        u = s[i + 24 >> 2],
                                                                            e = s[i + 12 >> 2];
                                                                        c: {
                                                                            if ((0 | i) != (0 | e)) {
                                                                                t = s[i + 8 >> 2],
                                                                                    s[t + 12 >> 2] = e,
                                                                                    s[e + 8 >> 2] = t;
                                                                                break c
                                                                            }
                                                                            l: {
                                                                                if (!(r = s[(t = i + 20 | 0) >> 2])) {
                                                                                    if (!(r = s[i + 16 >> 2]))
                                                                                        break l;
                                                                                    t = i + 16 | 0
                                                                                }
                                                                                for (; n = t,
                                                                                    !(!(r = s[(t = (e = r) + 20 | 0) >> 2]) && (t = e + 16 | 0,
                                                                                        !(r = s[e + 16 >> 2])));)
                                                                                    ;
                                                                                s[n >> 2] = 0;
                                                                                break c
                                                                            }
                                                                            e = 0
                                                                        }
                                                                        if (!u)
                                                                            break s;
                                                                        t = ((r = s[i + 28 >> 2]) << 2) + 2904 | 0;
                                                                        c: {
                                                                            if (s[t >> 2] == (0 | i)) {
                                                                                if (s[t >> 2] = e,
                                                                                    e)
                                                                                    break c;
                                                                                s[651] = s[651] & k(-2, r);
                                                                                break s
                                                                            }
                                                                            if (s[u + (s[u + 16 >> 2] == (0 | i) ? 16 : 20) >> 2] = e,
                                                                                !e)
                                                                                break s
                                                                        }
                                                                        if (s[e + 24 >> 2] = u,
                                                                            (t = s[i + 16 >> 2]) && (s[e + 16 >> 2] = t,
                                                                                s[t + 24 >> 2] = e),
                                                                            !(t = s[i + 20 >> 2]))
                                                                            break s;
                                                                        s[e + 20 >> 2] = t,
                                                                            s[t + 24 >> 2] = e
                                                                    }
                                                                    o = a + o | 0,
                                                                        r = s[(i = i + a | 0) + 4 >> 2]
                                                                }
                                                                if (s[i + 4 >> 2] = -2 & r,
                                                                    s[d + 4 >> 2] = 1 | o,
                                                                    s[o + d >> 2] = o,
                                                                    o >>> 0 <= 255) {
                                                                    t = (-8 & o) + 2640 | 0,
                                                                        r = s[650],
                                                                        e = 1 << (o >>> 3);
                                                                    s: {
                                                                        if (!(r & e)) {
                                                                            s[650] = e | r,
                                                                                e = t;
                                                                            break s
                                                                        }
                                                                        e = s[t + 8 >> 2]
                                                                    }
                                                                    s[t + 8 >> 2] = d,
                                                                        s[e + 12 >> 2] = d,
                                                                        s[d + 12 >> 2] = t,
                                                                        s[d + 8 >> 2] = e;
                                                                    break o
                                                                }
                                                                r = 31,
                                                                    o >>> 0 <= 16777215 && (e = f(o >>> 8 | 0),
                                                                        r = ((o >>> 38 - e & 1) - (e << 1) | 0) + 62 | 0),
                                                                    s[d + 28 >> 2] = r,
                                                                    s[d + 16 >> 2] = 0,
                                                                    s[d + 20 >> 2] = 0,
                                                                    t = (r << 2) + 2904 | 0;
                                                                s: {
                                                                    n = s[651],
                                                                        e = 1 << r;
                                                                    c: {
                                                                        if (!(n & e)) {
                                                                            s[651] = e | n,
                                                                                s[t >> 2] = d;
                                                                            break c
                                                                        }
                                                                        for (r = o << ((0 | r) != 31 ? 25 - (r >>> 1 | 0) | 0 : 0),
                                                                            e = s[t >> 2]; ;) {
                                                                            if (t = e,
                                                                                (-8 & s[e + 4 >> 2]) == (0 | o))
                                                                                break s;
                                                                            if (n = r >>> 29 | 0,
                                                                                r <<= 1,
                                                                                !(e = s[(n = (4 & n) + e | 0) + 16 >> 2]))
                                                                                break
                                                                        }
                                                                        s[n + 16 >> 2] = d
                                                                    }
                                                                    s[d + 24 >> 2] = t,
                                                                        s[d + 12 >> 2] = d,
                                                                        s[d + 8 >> 2] = d;
                                                                    break o
                                                                }
                                                                e = s[t + 8 >> 2],
                                                                    s[e + 12 >> 2] = d,
                                                                    s[t + 8 >> 2] = d,
                                                                    s[d + 24 >> 2] = 0,
                                                                    s[d + 12 >> 2] = t,
                                                                    s[d + 8 >> 2] = e
                                                            }
                                                            e = h + 8 | 0;
                                                            break e
                                                        }
                                                        e = s[t + 8 >> 2],
                                                            s[e + 12 >> 2] = i,
                                                            s[t + 8 >> 2] = i,
                                                            s[i + 24 >> 2] = 0,
                                                            s[i + 12 >> 2] = t,
                                                            s[i + 8 >> 2] = e
                                                    }
                                                    if ((e = s[653]) >>> 0 <= u >>> 0)
                                                        break n;
                                                    t = e - u | 0,
                                                        s[653] = t,
                                                        e = (r = s[656]) + u | 0,
                                                        s[656] = e,
                                                        s[e + 4 >> 2] = 1 | t,
                                                        s[r + 4 >> 2] = 3 | u,
                                                        e = r + 8 | 0;
                                                    break e
                                                }
                                                s[649] = 48,
                                                    e = 0;
                                                break e
                                            }
                                            r: if (o) {
                                                e = ((t = s[n + 28 >> 2]) << 2) + 2904 | 0;
                                                n: {
                                                    if (s[e >> 2] == (0 | n)) {
                                                        if (s[e >> 2] = r,
                                                            r)
                                                            break n;
                                                        h = k(-2, t) & h,
                                                            s[651] = h;
                                                        break r
                                                    }
                                                    if (s[o + (s[o + 16 >> 2] == (0 | n) ? 16 : 20) >> 2] = r,
                                                        !r)
                                                        break r
                                                }
                                                if (s[r + 24 >> 2] = o,
                                                    (e = s[n + 16 >> 2]) && (s[r + 16 >> 2] = e,
                                                        s[e + 24 >> 2] = r),
                                                    !(e = s[n + 20 >> 2]))
                                                    break r;
                                                s[r + 20 >> 2] = e,
                                                    s[e + 24 >> 2] = r
                                            }
                                            r: {
                                                if (i >>> 0 <= 15) {
                                                    e = i + u | 0,
                                                        s[n + 4 >> 2] = 3 | e,
                                                        s[(e = e + n | 0) + 4 >> 2] = 1 | s[e + 4 >> 2];
                                                    break r
                                                }
                                                if (s[n + 4 >> 2] = 3 | u,
                                                    s[(a = n + u | 0) + 4 >> 2] = 1 | i,
                                                    s[i + a >> 2] = i,
                                                    i >>> 0 <= 255) {
                                                    t = (-8 & i) + 2640 | 0,
                                                        r = s[650],
                                                        e = 1 << (i >>> 3);
                                                    n: {
                                                        if (!(r & e)) {
                                                            s[650] = e | r,
                                                                e = t;
                                                            break n
                                                        }
                                                        e = s[t + 8 >> 2]
                                                    }
                                                    s[t + 8 >> 2] = a,
                                                        s[e + 12 >> 2] = a,
                                                        s[a + 12 >> 2] = t,
                                                        s[a + 8 >> 2] = e;
                                                    break r
                                                }
                                                e = 31,
                                                    i >>> 0 <= 16777215 && (e = f(i >>> 8 | 0),
                                                        e = ((i >>> 38 - e & 1) - (e << 1) | 0) + 62 | 0),
                                                    s[a + 28 >> 2] = e,
                                                    s[a + 16 >> 2] = 0,
                                                    s[a + 20 >> 2] = 0,
                                                    t = (e << 2) + 2904 | 0;
                                                n: {
                                                    r = 1 << e;
                                                    i: {
                                                        if (!(r & h)) {
                                                            s[651] = r | h,
                                                                s[t >> 2] = a;
                                                            break i
                                                        }
                                                        for (e = i << ((0 | e) != 31 ? 25 - (e >>> 1 | 0) | 0 : 0),
                                                            u = s[t >> 2]; ;) {
                                                            if ((-8 & s[(t = u) + 4 >> 2]) == (0 | i))
                                                                break n;
                                                            if (r = e >>> 29 | 0,
                                                                e <<= 1,
                                                                !(u = s[(r = (4 & r) + t | 0) + 16 >> 2]))
                                                                break
                                                        }
                                                        s[r + 16 >> 2] = a
                                                    }
                                                    s[a + 24 >> 2] = t,
                                                        s[a + 12 >> 2] = a,
                                                        s[a + 8 >> 2] = a;
                                                    break r
                                                }
                                                e = s[t + 8 >> 2],
                                                    s[e + 12 >> 2] = a,
                                                    s[t + 8 >> 2] = a,
                                                    s[a + 24 >> 2] = 0,
                                                    s[a + 12 >> 2] = t,
                                                    s[a + 8 >> 2] = e
                                            }
                                            e = n + 8 | 0;
                                            break e
                                        }
                                        t: if (d) {
                                            e = ((t = s[r + 28 >> 2]) << 2) + 2904 | 0;
                                            r: {
                                                if (s[e >> 2] == (0 | r)) {
                                                    if (s[e >> 2] = n,
                                                        n)
                                                        break r;
                                                    s[651] = k(-2, t) & h;
                                                    break t
                                                }
                                                if (s[d + (s[d + 16 >> 2] == (0 | r) ? 16 : 20) >> 2] = n,
                                                    !n)
                                                    break t
                                            }
                                            if (s[n + 24 >> 2] = d,
                                                (e = s[r + 16 >> 2]) && (s[n + 16 >> 2] = e,
                                                    s[e + 24 >> 2] = n),
                                                !(e = s[r + 20 >> 2]))
                                                break t;
                                            s[n + 20 >> 2] = e,
                                                s[e + 24 >> 2] = n
                                        }
                                        t: {
                                            if (i >>> 0 <= 15) {
                                                e = i + u | 0,
                                                    s[r + 4 >> 2] = 3 | e,
                                                    s[(e = e + r | 0) + 4 >> 2] = 1 | s[e + 4 >> 2];
                                                break t
                                            }
                                            if (s[r + 4 >> 2] = 3 | u,
                                                s[(n = r + u | 0) + 4 >> 2] = 1 | i,
                                                s[n + i >> 2] = i,
                                                g) {
                                                t = (-8 & g) + 2640 | 0,
                                                    a = s[655],
                                                    e = 1 << (g >>> 3);
                                                r: {
                                                    if (!(e & o)) {
                                                        s[650] = e | o,
                                                            e = t;
                                                        break r
                                                    }
                                                    e = s[t + 8 >> 2]
                                                }
                                                s[t + 8 >> 2] = a,
                                                    s[e + 12 >> 2] = a,
                                                    s[a + 12 >> 2] = t,
                                                    s[a + 8 >> 2] = e
                                            }
                                            s[655] = n,
                                                s[652] = i
                                        }
                                        e = r + 8 | 0
                                    }
                                    return p = b + 16 | 0,
                                        0 | e
                                }
                                function m(e) {
                                    e |= 0;
                                    var t = 0
                                        , r = 0
                                        , n = 0
                                        , i = 0
                                        , a = 0
                                        , o = 0
                                        , c = 0;
                                    e: if (e) {
                                        a = (n = e - 8 | 0) + (e = -8 & (t = s[e - 4 >> 2])) | 0;
                                        t: if (!(1 & t)) {
                                            if (!(2 & t) || (t = s[n >> 2],
                                                (n = n - t | 0) >>> 0 < l[654]))
                                                break e;
                                            e = e + t | 0;
                                            r: {
                                                n: {
                                                    if (s[655] != (0 | n)) {
                                                        if (t >>> 0 <= 255) {
                                                            if (i = t >>> 3 | 0,
                                                                (0 | (t = s[n + 12 >> 2])) == (0 | (r = s[n + 8 >> 2]))) {
                                                                s[650] = s[650] & k(-2, i);
                                                                break t
                                                            }
                                                            s[r + 12 >> 2] = t,
                                                                s[t + 8 >> 2] = r;
                                                            break t
                                                        }
                                                        if (c = s[n + 24 >> 2],
                                                            t = s[n + 12 >> 2],
                                                            (0 | n) != (0 | t)) {
                                                            r = s[n + 8 >> 2],
                                                                s[r + 12 >> 2] = t,
                                                                s[t + 8 >> 2] = r;
                                                            break r
                                                        }
                                                        if (!(r = s[(i = n + 20 | 0) >> 2])) {
                                                            if (!(r = s[n + 16 >> 2]))
                                                                break n;
                                                            i = n + 16 | 0
                                                        }
                                                        for (; o = i,
                                                            !(!(r = s[(i = (t = r) + 20 | 0) >> 2]) && (i = t + 16 | 0,
                                                                !(r = s[t + 16 >> 2])));)
                                                            ;
                                                        s[o >> 2] = 0;
                                                        break r
                                                    }
                                                    if ((3 & (t = s[a + 4 >> 2])) != 3)
                                                        break t;
                                                    s[652] = e,
                                                        s[a + 4 >> 2] = -2 & t,
                                                        s[n + 4 >> 2] = 1 | e,
                                                        s[a >> 2] = e;
                                                    return
                                                }
                                                t = 0
                                            }
                                            if (!c)
                                                break t;
                                            i = ((r = s[n + 28 >> 2]) << 2) + 2904 | 0;
                                            r: {
                                                if (s[i >> 2] == (0 | n)) {
                                                    if (s[i >> 2] = t,
                                                        t)
                                                        break r;
                                                    s[651] = s[651] & k(-2, r);
                                                    break t
                                                }
                                                if (s[c + (s[c + 16 >> 2] == (0 | n) ? 16 : 20) >> 2] = t,
                                                    !t)
                                                    break t
                                            }
                                            if (s[t + 24 >> 2] = c,
                                                (r = s[n + 16 >> 2]) && (s[t + 16 >> 2] = r,
                                                    s[r + 24 >> 2] = t),
                                                !(r = s[n + 20 >> 2]))
                                                break t;
                                            s[t + 20 >> 2] = r,
                                                s[r + 24 >> 2] = t
                                        }
                                        if (n >>> 0 >= a >>> 0 || !(1 & (t = s[a + 4 >> 2])))
                                            break e;
                                        t: {
                                            r: {
                                                n: {
                                                    i: {
                                                        if (!(2 & t)) {
                                                            if (s[656] == (0 | a)) {
                                                                if (s[656] = n,
                                                                    e = s[653] + e | 0,
                                                                    s[653] = e,
                                                                    s[n + 4 >> 2] = 1 | e,
                                                                    s[655] != (0 | n))
                                                                    break e;
                                                                s[652] = 0,
                                                                    s[655] = 0;
                                                                return
                                                            }
                                                            if (s[655] == (0 | a)) {
                                                                s[655] = n,
                                                                    e = s[652] + e | 0,
                                                                    s[652] = e,
                                                                    s[n + 4 >> 2] = 1 | e,
                                                                    s[e + n >> 2] = e;
                                                                return
                                                            }
                                                            if (e = (-8 & t) + e | 0,
                                                                t >>> 0 <= 255) {
                                                                if (i = t >>> 3 | 0,
                                                                    (0 | (t = s[a + 12 >> 2])) == (0 | (r = s[a + 8 >> 2]))) {
                                                                    s[650] = s[650] & k(-2, i);
                                                                    break r
                                                                }
                                                                s[r + 12 >> 2] = t,
                                                                    s[t + 8 >> 2] = r;
                                                                break r
                                                            }
                                                            if (c = s[a + 24 >> 2],
                                                                t = s[a + 12 >> 2],
                                                                (0 | a) != (0 | t)) {
                                                                r = s[a + 8 >> 2],
                                                                    s[r + 12 >> 2] = t,
                                                                    s[t + 8 >> 2] = r;
                                                                break n
                                                            }
                                                            if (!(r = s[(i = a + 20 | 0) >> 2])) {
                                                                if (!(r = s[a + 16 >> 2]))
                                                                    break i;
                                                                i = a + 16 | 0
                                                            }
                                                            for (; o = i,
                                                                !(!(r = s[(i = (t = r) + 20 | 0) >> 2]) && (i = t + 16 | 0,
                                                                    !(r = s[t + 16 >> 2])));)
                                                                ;
                                                            s[o >> 2] = 0;
                                                            break n
                                                        }
                                                        s[a + 4 >> 2] = -2 & t,
                                                            s[n + 4 >> 2] = 1 | e,
                                                            s[e + n >> 2] = e;
                                                        break t
                                                    }
                                                    t = 0
                                                }
                                                if (!c)
                                                    break r;
                                                i = ((r = s[a + 28 >> 2]) << 2) + 2904 | 0;
                                                n: {
                                                    if (s[i >> 2] == (0 | a)) {
                                                        if (s[i >> 2] = t,
                                                            t)
                                                            break n;
                                                        s[651] = s[651] & k(-2, r);
                                                        break r
                                                    }
                                                    if (s[c + (s[c + 16 >> 2] == (0 | a) ? 16 : 20) >> 2] = t,
                                                        !t)
                                                        break r
                                                }
                                                if (s[t + 24 >> 2] = c,
                                                    (r = s[a + 16 >> 2]) && (s[t + 16 >> 2] = r,
                                                        s[r + 24 >> 2] = t),
                                                    !(r = s[a + 20 >> 2]))
                                                    break r;
                                                s[t + 20 >> 2] = r,
                                                    s[r + 24 >> 2] = t
                                            }
                                            if (s[n + 4 >> 2] = 1 | e,
                                                s[e + n >> 2] = e,
                                                s[655] != (0 | n))
                                                break t;
                                            s[652] = e;
                                            return
                                        }
                                        if (e >>> 0 <= 255) {
                                            t = (-8 & e) + 2640 | 0,
                                                r = s[650],
                                                e = 1 << (e >>> 3);
                                            t: {
                                                if (!(r & e)) {
                                                    s[650] = e | r,
                                                        e = t;
                                                    break t
                                                }
                                                e = s[t + 8 >> 2]
                                            }
                                            s[t + 8 >> 2] = n,
                                                s[e + 12 >> 2] = n,
                                                s[n + 12 >> 2] = t,
                                                s[n + 8 >> 2] = e;
                                            return
                                        }
                                        r = 31,
                                            e >>> 0 <= 16777215 && (t = f(e >>> 8 | 0),
                                                r = ((e >>> 38 - t & 1) - (t << 1) | 0) + 62 | 0),
                                            s[n + 28 >> 2] = r,
                                            s[n + 16 >> 2] = 0,
                                            s[n + 20 >> 2] = 0,
                                            t = (r << 2) + 2904 | 0;
                                        t: {
                                            r: {
                                                i = s[651],
                                                    o = 1 << r;
                                                n: {
                                                    if (!(i & o)) {
                                                        s[651] = i | o,
                                                            s[t >> 2] = n,
                                                            s[n + 24 >> 2] = t;
                                                        break n
                                                    }
                                                    for (r = e << ((0 | r) != 31 ? 25 - (r >>> 1 | 0) | 0 : 0),
                                                        t = s[t >> 2]; ;) {
                                                        if (i = t,
                                                            (-8 & s[t + 4 >> 2]) == (0 | e))
                                                            break r;
                                                        if (o = r >>> 29 | 0,
                                                            r <<= 1,
                                                            !(t = s[(o = t + (4 & o) | 0) + 16 >> 2]))
                                                            break
                                                    }
                                                    s[o + 16 >> 2] = n,
                                                        s[n + 24 >> 2] = i
                                                }
                                                s[n + 12 >> 2] = n,
                                                    s[n + 8 >> 2] = n;
                                                break t
                                            }
                                            e = s[i + 8 >> 2],
                                                s[e + 12 >> 2] = n,
                                                s[i + 8 >> 2] = n,
                                                s[n + 24 >> 2] = 0,
                                                s[n + 12 >> 2] = i,
                                                s[n + 8 >> 2] = e
                                        }
                                        e = s[658] - 1 | 0,
                                            s[658] = e || -1
                                    }
                                }
                                function v(e) {
                                    var t = 0
                                        , r = 0;
                                    return !((e = (t = s[384]) + (r = e + 7 & -8) | 0) >>> 0 <= t >>> 0 && r) && (e >>> 0 <= (a.byteLength / 65536 | 0) << 16 >>> 0 || 0 | h(0 | e)) ? (s[384] = e,
                                        t) : (s[649] = 48,
                                            -1)
                                }
                                function k(e, t) {
                                    var r = 0;
                                    return (-1 >>> (r = 31 & t) & e) << r | ((r = e) & -1 << (e = 0 - t & 31)) >>> e
                                }
                                function y(e) {
                                    return e ? 31 - f(e - 1 ^ e) | 0 : 32
                                }
                                return i(t = c, 1024, "BwAAAAwAAAARAAAAFgAAAAcAAAAMAAAAEQAAABYAAAAHAAAADAAAABEAAAAWAAAABwAAAAwAAAARAAAAFgAAAAUAAAAJAAAADgAAABQAAAAFAAAACQAAAA4AAAAUAAAABQAAAAkAAAAOAAAAFAAAAAUAAAAJAAAADgAAABQAAAAEAAAACwAAABAAAAAXAAAABAAAAAsAAAAQAAAAFwAAAAQAAAALAAAAEAAAABcAAAAEAAAACwAAABAAAAAXAAAABgAAAAoAAAAPAAAAFQAAAAYAAAAKAAAADwAAABUAAAAGAAAACgAAAA8AAAAVAAAABgAAAAoAAAAPAAAAFQAAAHikatdWt8fo23AgJO7OvcGvD3z1KsaHRxNGMKgBlUb92JiAaa/3RIuxW///vtdciSIRkGuTcZj9jkN5piEItEliJR72QLNAwFFaXiaqx7bpXRAv1lMURAKB5qHYyPvT5+bN4SHWBzfDhw3V9O0UWkUF6eOp+KPv/NkCb2eKTCqNQjn6/4H2cYciYZ1tDDjl/UTqvqSpz95LYEu79nC8v77Gfpso+ieh6oUw79QFHYgEOdDU2eWZ2+b4fKIfZVasxEQiKfSX/ypDpyOUqzmgk/zDWVtlkswMj3307//RXYSFT36ob+DmLP4UQwGjoREIToJ+U/c18jq9u9LXKpHThus="),
                                    i(t, 1536, "IAwB"),
                                {
                                    e: function () { },
                                    f: m,
                                    g: function (e) {
                                        e |= 0;
                                        var t = 0
                                            , r = 0;
                                        t = A(12),
                                            s[648] = t,
                                            r = c[e + 8 | 0] | c[e + 9 | 0] << 8 | (c[e + 10 | 0] << 16 | c[e + 11 | 0] << 24),
                                            o[t + 8 | 0] = r,
                                            o[t + 9 | 0] = r >>> 8,
                                            o[t + 10 | 0] = r >>> 16,
                                            o[t + 11 | 0] = r >>> 24,
                                            r = c[e + 4 | 0] | c[e + 5 | 0] << 8 | (c[e + 6 | 0] << 16 | c[e + 7 | 0] << 24),
                                            e = c[0 | e] | c[e + 1 | 0] << 8 | (c[e + 2 | 0] << 16 | c[e + 3 | 0] << 24),
                                            o[0 | t] = e,
                                            o[t + 1 | 0] = e >>> 8,
                                            o[t + 2 | 0] = e >>> 16,
                                            o[t + 3 | 0] = e >>> 24,
                                            e = r,
                                            o[t + 4 | 0] = e,
                                            o[t + 5 | 0] = e >>> 8,
                                            o[t + 6 | 0] = e >>> 16,
                                            o[t + 7 | 0] = e >>> 24
                                    },
                                    h: A,
                                    i: function (e, t, r) {
                                        e |= 0,
                                            t |= 0,
                                            r |= 0;
                                        var n = 0
                                            , i = 0
                                            , a = 0
                                            , l = 0
                                            , f = 0
                                            , h = 0
                                            , p = 0
                                            , v = 0
                                            , y = 0
                                            , w = 0
                                            , x = 0
                                            , E = 0
                                            , T = 0
                                            , S = 0
                                            , j = 0
                                            , _ = 0
                                            , I = 0;
                                        E = A(32),
                                            l = A(16),
                                            a = t,
                                            t = (h = t + 8 & -64) + 120 | 0,
                                            n = 0;
                                        e: if (!t || (1 | (n = t)) >>> 0 < 65536)
                                            break e;
                                        if (!(!(t = A(n)) | !(3 & c[t - 4 | 0])) && n && (o[0 | t] = 0,
                                            o[(i = t + n | 0) - 1 | 0] = 0,
                                            !(n >>> 0 < 3)) && (o[t + 2 | 0] = 0,
                                                o[t + 1 | 0] = 0,
                                                o[i - 3 | 0] = 0,
                                                o[i - 2 | 0] = 0,
                                                !(n >>> 0 < 7)) && (o[t + 3 | 0] = 0,
                                                    o[i - 4 | 0] = 0,
                                                    !(n >>> 0 < 9)) && (s[(f = (i = 0 - t & 3) + t | 0) >> 2] = 0,
                                                        s[(n = (i = n - i & -4) + f | 0) - 4 >> 2] = 0,
                                                        !(i >>> 0 < 9)) && (s[f + 8 >> 2] = 0,
                                                            s[f + 4 >> 2] = 0,
                                                            s[n - 8 >> 2] = 0,
                                                            s[n - 12 >> 2] = 0,
                                                            !(i >>> 0 < 25)) && (s[f + 24 >> 2] = 0,
                                                                s[f + 20 >> 2] = 0,
                                                                s[f + 16 >> 2] = 0,
                                                                s[f + 12 >> 2] = 0,
                                                                s[n - 16 >> 2] = 0,
                                                                s[n - 20 >> 2] = 0,
                                                                s[n - 24 >> 2] = 0,
                                                                s[n - 28 >> 2] = 0,
                                                                !((i = i - (n = 4 & f | 24) | 0) >>> 0 < 32)))
                                            for (n = n + f | 0; s[n + 24 >> 2] = 0,
                                                s[n + 28 >> 2] = 0,
                                                s[n + 16 >> 2] = 0,
                                                s[n + 20 >> 2] = 0,
                                                s[n + 8 >> 2] = 0,
                                                s[n + 12 >> 2] = 0,
                                                s[n >> 2] = 0,
                                                s[n + 4 >> 2] = 0,
                                                n = n + 32 | 0,
                                                (i = i - 32 | 0) >>> 0 > 31;)
                                                ;
                                        n = e;
                                        e: {
                                            if (a >>> 0 >= 512) {
                                                b(0 | t, 0 | n, 0 | a);
                                                break e
                                            }
                                            i = t + a | 0;
                                            t: {
                                                if (!((t ^ n) & 3)) {
                                                    r: {
                                                        if (!(3 & t) || !a) {
                                                            e = t;
                                                            break r
                                                        }
                                                        for (e = t; ;) {
                                                            if (o[0 | e] = c[0 | n],
                                                                n = n + 1 | 0,
                                                                !(3 & (e = e + 1 | 0)))
                                                                break r;
                                                            if (!(e >>> 0 < i >>> 0))
                                                                break
                                                        }
                                                    }
                                                    if (!((f = -4 & i) >>> 0 < 64) && !((p = f + -64 | 0) >>> 0 < e >>> 0))
                                                        for (; s[e >> 2] = s[n >> 2],
                                                            s[e + 4 >> 2] = s[n + 4 >> 2],
                                                            s[e + 8 >> 2] = s[n + 8 >> 2],
                                                            s[e + 12 >> 2] = s[n + 12 >> 2],
                                                            s[e + 16 >> 2] = s[n + 16 >> 2],
                                                            s[e + 20 >> 2] = s[n + 20 >> 2],
                                                            s[e + 24 >> 2] = s[n + 24 >> 2],
                                                            s[e + 28 >> 2] = s[n + 28 >> 2],
                                                            s[e + 32 >> 2] = s[n + 32 >> 2],
                                                            s[e + 36 >> 2] = s[n + 36 >> 2],
                                                            s[e + 40 >> 2] = s[n + 40 >> 2],
                                                            s[e + 44 >> 2] = s[n + 44 >> 2],
                                                            s[e + 48 >> 2] = s[n + 48 >> 2],
                                                            s[e + 52 >> 2] = s[n + 52 >> 2],
                                                            s[e + 56 >> 2] = s[n + 56 >> 2],
                                                            s[e + 60 >> 2] = s[n + 60 >> 2],
                                                            n = n - -64 | 0,
                                                            p >>> 0 >= (e = e - -64 | 0) >>> 0;)
                                                            ;
                                                    if (e >>> 0 >= f >>> 0)
                                                        break t;
                                                    for (; s[e >> 2] = s[n >> 2],
                                                        n = n + 4 | 0,
                                                        f >>> 0 > (e = e + 4 | 0) >>> 0;)
                                                        ;
                                                    break t
                                                }
                                                if (i >>> 0 < 4 || (f = i - 4 | 0) >>> 0 < t >>> 0) {
                                                    e = t;
                                                    break t
                                                }
                                                for (e = t; o[0 | e] = c[0 | n],
                                                    o[e + 1 | 0] = c[n + 1 | 0],
                                                    o[e + 2 | 0] = c[n + 2 | 0],
                                                    o[e + 3 | 0] = c[n + 3 | 0],
                                                    n = n + 4 | 0,
                                                    f >>> 0 >= (e = e + 4 | 0) >>> 0;)
                                                    ;
                                            }
                                            if (e >>> 0 < i >>> 0)
                                                for (; o[0 | e] = c[0 | n],
                                                    n = n + 1 | 0,
                                                    (0 | i) != (0 | (e = e + 1 | 0));)
                                                    ;
                                        }
                                        if (T = t,
                                            o[a + t | 0] = 128,
                                            e = (S = 56 | h) + t | 0,
                                            t = a << 3,
                                            o[0 | e] = t,
                                            o[e + 1 | 0] = t >>> 8,
                                            o[e + 2 | 0] = t >>> 16,
                                            o[e + 3 | 0] = t >>> 24,
                                            (0 | h) >= 0) {
                                            for (h = 271733878,
                                                p = -1732584194,
                                                v = -271733879,
                                                y = 1732584193; ;) {
                                                for (_ = T + x | 0,
                                                    f = 0,
                                                    n = h,
                                                    t = p,
                                                    i = v,
                                                    e = y; ;) {
                                                    I = e,
                                                        e = n,
                                                        a = i,
                                                        a = i;
                                                    e: {
                                                        if (f >>> 0 <= 15) {
                                                            i = (-1 ^ i) & n | t & i,
                                                                w = f;
                                                            break e
                                                        }
                                                        if (f >>> 0 <= 31) {
                                                            i = e & a | (-1 ^ e) & t,
                                                                w = u(f, 5) + 1 & 15;
                                                            break e
                                                        }
                                                        if (f >>> 0 <= 47) {
                                                            i = t ^ a ^ e,
                                                                w = u(f, 3) + 5 & 15;
                                                            break e
                                                        }
                                                        i = (a | -1 ^ e) ^ t,
                                                            w = 15 & u(f, 7)
                                                    }
                                                    if (n = f << 2,
                                                        i = a + k(s[(w << 2) + _ >> 2] + (s[n + 1280 >> 2] + (i + I | 0) | 0) | 0, s[n + 1024 >> 2]) | 0,
                                                        n = t,
                                                        t = a,
                                                        (0 | (f = f + 1 | 0)) == 64)
                                                        break
                                                }
                                                if (h = n + h | 0,
                                                    p = t + p | 0,
                                                    v = i + v | 0,
                                                    y = e + y | 0,
                                                    !((0 | S) > (0 | (x = x - -64 | 0))))
                                                    break
                                            }
                                            o[l + 12 | 0] = h,
                                                o[l + 13 | 0] = h >>> 8,
                                                o[l + 14 | 0] = h >>> 16,
                                                o[l + 15 | 0] = h >>> 24,
                                                o[l + 8 | 0] = p,
                                                o[l + 9 | 0] = p >>> 8,
                                                o[l + 10 | 0] = p >>> 16,
                                                o[l + 11 | 0] = p >>> 24,
                                                o[l + 4 | 0] = v,
                                                o[l + 5 | 0] = v >>> 8,
                                                o[l + 6 | 0] = v >>> 16,
                                                o[l + 7 | 0] = v >>> 24,
                                                o[0 | l] = y,
                                                o[l + 1 | 0] = y >>> 8,
                                                o[l + 2 | 0] = y >>> 16,
                                                o[l + 3 | 0] = y >>> 24
                                        }
                                        m(T),
                                            t = 0,
                                            j = +g() / 1e3;
                                        e: {
                                            if (0x7fffffffffffffff > d(j)) {
                                                i = ~~j >>> 0;
                                                break e
                                            }
                                            i = 0
                                        }
                                        for (n = c[l + 12 | 0] | c[l + 13 | 0] << 8 | (c[l + 14 | 0] << 16 | c[l + 15 | 0] << 24),
                                            e = E,
                                            a = c[l + 8 | 0] | c[l + 9 | 0] << 8 | (c[l + 10 | 0] << 16 | c[l + 11 | 0] << 24),
                                            o[e + 8 | 0] = a,
                                            o[e + 9 | 0] = a >>> 8,
                                            o[e + 10 | 0] = a >>> 16,
                                            o[e + 11 | 0] = a >>> 24,
                                            o[e + 12 | 0] = n,
                                            o[e + 13 | 0] = n >>> 8,
                                            o[e + 14 | 0] = n >>> 16,
                                            o[e + 15 | 0] = n >>> 24,
                                            n = c[l + 4 | 0] | c[l + 5 | 0] << 8 | (c[l + 6 | 0] << 16 | c[l + 7 | 0] << 24),
                                            a = c[0 | l] | c[l + 1 | 0] << 8 | (c[l + 2 | 0] << 16 | c[l + 3 | 0] << 24),
                                            o[0 | e] = a,
                                            o[e + 1 | 0] = a >>> 8,
                                            o[e + 2 | 0] = a >>> 16,
                                            o[e + 3 | 0] = a >>> 24,
                                            o[e + 4 | 0] = n,
                                            o[e + 5 | 0] = n >>> 8,
                                            o[e + 6 | 0] = n >>> 16,
                                            o[e + 7 | 0] = n >>> 24,
                                            n = (n = i - ((i >>> 0) % 100 | 0) | 0) << 24 | (65280 & n) << 8 | (n >>> 8 & 65280 | n >>> 24),
                                            o[e + 16 | 0] = n,
                                            o[e + 17 | 0] = n >>> 8,
                                            o[e + 18 | 0] = n >>> 16,
                                            o[e + 19 | 0] = n >>> 24,
                                            i = c[(n = s[648]) + 4 | 0] | c[n + 5 | 0] << 8 | (c[n + 6 | 0] << 16 | c[n + 7 | 0] << 24),
                                            a = c[0 | n] | c[n + 1 | 0] << 8 | (c[n + 2 | 0] << 16 | c[n + 3 | 0] << 24),
                                            o[e + 20 | 0] = a,
                                            o[e + 21 | 0] = a >>> 8,
                                            o[e + 22 | 0] = a >>> 16,
                                            o[e + 23 | 0] = a >>> 24,
                                            o[e + 24 | 0] = i,
                                            o[e + 25 | 0] = i >>> 8,
                                            o[e + 26 | 0] = i >>> 16,
                                            o[e + 27 | 0] = i >>> 24,
                                            n = c[n + 8 | 0] | c[n + 9 | 0] << 8 | (c[n + 10 | 0] << 16 | c[n + 11 | 0] << 24),
                                            o[e + 28 | 0] = n,
                                            o[e + 29 | 0] = n >>> 8,
                                            o[e + 30 | 0] = n >>> 16,
                                            o[e + 31 | 0] = n >>> 24,
                                            m(l),
                                            e = 0; s[(e << 2) + 1568 >> 2] = e,
                                            s[((n = 1 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 2 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 3 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 4 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 5 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 6 | e) << 2) + 1568 >> 2] = n,
                                            s[((n = 7 | e) << 2) + 1568 >> 2] = n,
                                            (0 | (e = e + 8 | 0)) != 256;)
                                            ;
                                        for (e = 0; a = s[(i = (t << 2) + 1568 | 0) >> 2],
                                            n = ((e = (c[(31 & t) + E | 0] + (a + e | 0) | 0) % 256 | 0) << 2) + 1568 | 0,
                                            s[i >> 2] = s[n >> 2],
                                            s[n >> 2] = 255 & a,
                                            (0 | (t = t + 1 | 0)) != 256;)
                                            ;
                                        for (e = 0; t = ((i = (s[388] + 1 | 0) % 256 | 0) << 2) + 1568 | 0,
                                            n = ((f = ((a = s[t >> 2]) + s[389] | 0) % 256 | 0) << 2) + 1568 | 0,
                                            s[t >> 2] = s[n >> 2],
                                            h = n,
                                            n = 255 & a,
                                            s[h >> 2] = n,
                                            s[388] = i,
                                            s[389] = f,
                                            o[e + r | 0] = (n + s[t >> 2] | 0) % 255,
                                            (0 | (e = e + 1 | 0)) != 32;)
                                            ;
                                        return s[389] = 0,
                                            s[388] = 0,
                                            1
                                    },
                                    j: ((r = []).set = function (e, t) {
                                        this[e] = t
                                    }
                                        ,
                                        r.get = function (e) {
                                            return this[e]
                                        }
                                        ,
                                        r),
                                    k: function () {
                                        return 0 | p
                                    },
                                    l: function (e) {
                                        e |= 0,
                                            p = e
                                    },
                                    m: function (e) {
                                        return e |= 0,
                                            p = e = p - e & -16,
                                            0 | e
                                    }
                                }
                            }(e)
                    }(t)
                },
                instantiate: function (e, t) {
                    return {
                        then: function (r) {
                            var n = new o.Module(e);
                            r({
                                instance: new o.Instance(n, t)
                            })
                        }
                    }
                },
                RuntimeError: Error
            };
            d = [],
                "object" != typeof o && x("no native wasm support detected");
            var s, c, l, u, d, f, h, g, b = !1, p = e.INITIAL_MEMORY || 16777216;
            E = (f = e.wasmMemory ? e.wasmMemory : new o.Memory({
                initial: p / 65536,
                maximum: p / 65536
            })).buffer,
                e.HEAP8 = h = new Int8Array(E),
                e.HEAP16 = new Int16Array(E),
                e.HEAPU8 = g = new Uint8Array(E),
                e.HEAPU16 = new Uint16Array(E),
                e.HEAP32 = new Int32Array(E),
                e.HEAPU32 = new Uint32Array(E),
                e.HEAPF32 = new Float32Array(E),
                e.HEAPF64 = new Float64Array(E),
                p = f.buffer.byteLength;
            var A = []
                , m = []
                , v = []
                , k = 0
                , y = null
                , w = null;
            function x(t) {
                null === (r = e.onAbort) || void 0 === r || r.call(e, t),
                    a(t = "Aborted(" + t + ")"),
                    b = !0,
                    t += ". Build with -sASSERTIONS for more info.";
                var r, n = new o.RuntimeError(t);
                throw l(n),
                n
            }
            var E, T, S = "data:application/octet-stream;base64,", j = e => e.startsWith(S);
            function _(e) {
                if (e == T && d)
                    return new Uint8Array(d);
                var t = function (e) {
                    if (j(e))
                        return function (e) {
                            for (var t = atob(e), r = new Uint8Array(t.length), n = 0; n < t.length; ++n)
                                r[n] = t.charCodeAt(n);
                            return r
                        }(e.slice(S.length))
                }(e);
                if (t)
                    return t;
                if (u)
                    return u(e);
                throw "both async and sync fetching of the wasm failed"
            }
            function I(e, t, r) {
                return (d || j(e) || "function" != typeof fetch ? Promise.resolve().then(() => _(e)) : fetch(e, {
                    credentials: "same-origin"
                }).then(t => {
                    if (!t.ok)
                        throw "failed to load wasm binary file at '" + e + "'";
                    return t.arrayBuffer()
                }
                ).catch(() => _(e))).then(e => o.instantiate(e, t)).then(e => e).then(r, e => {
                    a("failed to asynchronously prepare wasm: ".concat(e)),
                        x(e)
                }
                )
            }
            j(T = "asm.wasm") || (t = T,
                T = e.locateFile ? e.locateFile(t, n) : n + t);
            var N = t => {
                for (; t.length > 0;)
                    t.shift()(e)
            }
                , Z = (e.noExitRuntime,
                    e => {
                        x("OOM")
                    }
                )
                , P = t => e["_" + t]
                , C = (e, t) => {
                    h.set(e, t)
                }
                , R = e => {
                    for (var t = 0, r = 0; r < e.length; ++r) {
                        var n = e.charCodeAt(r);
                        n <= 127 ? t++ : n <= 2047 ? t += 2 : n >= 55296 && n <= 57343 ? (t += 4,
                            ++r) : t += 3
                    }
                    return t
                }
                , O = (e, t, r, n) => {
                    if (!(n > 0))
                        return 0;
                    for (var i = r, a = r + n - 1, o = 0; o < e.length; ++o) {
                        var s = e.charCodeAt(o);
                        if (s >= 55296 && s <= 57343 && (s = 65536 + ((1023 & s) << 10) | 1023 & e.charCodeAt(++o)),
                            s <= 127) {
                            if (r >= a)
                                break;
                            t[r++] = s
                        } else if (s <= 2047) {
                            if (r + 1 >= a)
                                break;
                            t[r++] = 192 | s >> 6,
                                t[r++] = 128 | 63 & s
                        } else if (s <= 65535) {
                            if (r + 2 >= a)
                                break;
                            t[r++] = 224 | s >> 12,
                                t[r++] = 128 | s >> 6 & 63,
                                t[r++] = 128 | 63 & s
                        } else {
                            if (r + 3 >= a)
                                break;
                            t[r++] = 240 | s >> 18,
                                t[r++] = 128 | s >> 12 & 63,
                                t[r++] = 128 | s >> 6 & 63,
                                t[r++] = 128 | 63 & s
                        }
                    }
                    return t[r] = 0,
                        r - i
                }
                , L = (e, t, r) => O(e, g, t, r)
                , W = e => {
                    var t = R(e) + 1
                        , r = H(t);
                    return L(e, r, t),
                        r
                }
                , M = "u" > typeof TextDecoder ? new TextDecoder("utf8") : void 0
                , q = (e, t, r) => {
                    for (var n = t + r, i = t; e[i] && !(i >= n);)
                        ++i;
                    if (i - t > 16 && e.buffer && M)
                        return M.decode(e.subarray(t, i));
                    for (var a = ""; t < i;) {
                        var o = e[t++];
                        if (!(128 & o)) {
                            a += String.fromCharCode(o);
                            continue
                        }
                        var s = 63 & e[t++];
                        if ((224 & o) == 192) {
                            a += String.fromCharCode((31 & o) << 6 | s);
                            continue
                        }
                        var c = 63 & e[t++];
                        if ((o = (240 & o) == 224 ? (15 & o) << 12 | s << 6 | c : (7 & o) << 18 | s << 12 | c << 6 | 63 & e[t++]) < 65536)
                            a += String.fromCharCode(o);
                        else {
                            var l = o - 65536;
                            a += String.fromCharCode(55296 | l >> 10, 56320 | 1023 & l)
                        }
                    }
                    return a
                }
                , B = (e, t) => e ? q(g, e, t) : ""
                , U = {
                    c: () => Date.now(),
                    d: (e, t, r) => g.copyWithin(e, t, t + r),
                    b: e => {
                        g.length,
                            Z(e >>>= 0)
                    }
                    ,
                    a: f
                }
                , G = function () {
                    var t, r, n, i, s = {
                        a: U
                    };
                    function c(t, r) {
                        var n;
                        return n = (G = t.exports).e,
                            m.unshift(n),
                            function (t) {
                                var r;
                                if (k--,
                                    null === (r = e.monitorRunDependencies) || void 0 === r || r.call(e, k),
                                    0 == k && (null !== y && (clearInterval(y),
                                        y = null),
                                        w)) {
                                    var n = w;
                                    w = null,
                                        n()
                                }
                            }(0),
                            G
                    }
                    if (k++,
                        null === (t = e.monitorRunDependencies) || void 0 === t || t.call(e, k),
                        e.instantiateWasm)
                        try {
                            return e.instantiateWasm(s, c)
                        } catch (e) {
                            a("Module.instantiateWasm callback failed with error: ".concat(e)),
                                l(e)
                        }
                    return (r = d,
                        n = T,
                        i = function (e) {
                            c(e.instance)
                        }
                        ,
                        r || "function" != typeof o.instantiateStreaming || j(n) || "function" != typeof fetch ? I(n, s, i) : fetch(n, {
                            credentials: "same-origin"
                        }).then(e => o.instantiateStreaming(e, s).then(i, function (e) {
                            return a("wasm streaming compile failed: ".concat(e)),
                                a("falling back to ArrayBuffer instantiation"),
                                I(n, s, i)
                        }))).catch(l),
                        {}
                }()
                , F = (e._free = t => (e._free = G.f)(t),
                    e._set_psk = t => (e._set_psk = G.g)(t),
                    e._malloc = t => (e._malloc = G.h)(t),
                    e._calc_sign = (t, r, n) => (e._calc_sign = G.i)(t, r, n),
                    () => (F = G.k)())
                , D = e => (D = G.l)(e)
                , H = e => (H = G.m)(e);
            function V() {
                k > 0 || (function () {
                    if (e.preRun)
                        for ("function" == typeof e.preRun && (e.preRun = [e.preRun]); e.preRun.length;) {
                            var t;
                            t = e.preRun.shift(),
                                A.unshift(t)
                        }
                    N(A)
                }(),
                    k > 0) || (e.setStatus ? (e.setStatus("Running..."),
                        setTimeout(function () {
                            setTimeout(function () {
                                e.setStatus("")
                            }, 1),
                                t()
                        }, 1)) : t());
                function t() {
                    s || (s = !0,
                        e.calledRun = !0,
                        b || (N(m),
                            c(e),
                            e.onRuntimeInitialized && e.onRuntimeInitialized(),
                            function () {
                                if (e.postRun)
                                    for ("function" == typeof e.postRun && (e.postRun = [e.postRun]); e.postRun.length;) {
                                        var t;
                                        t = e.postRun.shift(),
                                            v.unshift(t)
                                    }
                                N(v)
                            }()))
                }
            }
            if (e.ccall = (e, t, r, n, i) => {
                var a, o = {
                    string: e => {
                        var t = 0;
                        return null != e && 0 !== e && (t = W(e)),
                            t
                    }
                    ,
                    array: e => {
                        var t = H(e.length);
                        return C(e, t),
                            t
                    }
                }, s = P(e), c = [], l = 0;
                if (n)
                    for (var u = 0; u < n.length; u++) {
                        var d = o[r[u]];
                        d ? (0 === l && (l = F()),
                            c[u] = d(n[u])) : c[u] = n[u]
                    }
                var f = s.apply(null, c);
                return a = f,
                    0 !== l && D(l),
                    f = "string" === t ? B(a) : "boolean" === t ? !!a : a
            }
                ,
                e.UTF8ToString = B,
                e.stringToUTF8 = L,
                e.AsciiToString = e => {
                    for (var t = ""; ;) {
                        var r = g[e++ >> 0];
                        if (!r)
                            return t;
                        t += String.fromCharCode(r)
                    }
                }
                ,
                w = function e() {
                    s || V(),
                        s || (w = e)
                }
                ,
                e.preInit)
                for ("function" == typeof e.preInit && (e.preInit = [e.preInit]); e.preInit.length > 0;)
                    e.preInit.pop()();
            return V(),
                e.ready
        }
    );
    "object" == typeof r && "object" == typeof n ? n.exports = o : void 0 !== (a = (() => o).apply(t, [])) && (e.exports = a)
}
    ,
    () => (i || n((i = {
        exports: {}
    }).exports, i),
        i.exports)), f = {};
((e, t) => {
    for (var r in t)
        s(e, r, {
            get: t[r],
            enumerable: !0
        })
}
)(f, {
    NOSAntiSpamHelper: () => g
});
function uint8ArrayToHex(uint8Array) {
    return Array.from(uint8Array, byte => byte.toString(16).padStart(2, '0')).join('');
}
var h = d()
    , g = class {
        async init(e) {
            this.nativeSigner = await h(),
                this.nativeSigner.ccall("set_psk", "null", ["string"], [e]),
                this.initialized = !0
        }
        sign(e) {
            if (!this.initialized)
                throw Error("ASH is not initialized");
            let t = this.nativeSigner._malloc(32)
                , r = this.nativeSigner._malloc(e.length + 1);
            this.nativeSigner.stringToUTF8(e, r, e.length + 1),
                this.nativeSigner.ccall("calc_sign", "null", ["number", "number", "number"], [r, e.length, t]);
            let n = this.nativeSigner.HEAPU8.slice(t, t + 32)
            i = n;
            //, i = o.from(n).toString("hex").slice(0, 64);
            return this.nativeSigner._free(t),
                this.nativeSigner._free(r),
                i
        }
        constructor() {
            this.initialized = !1
        }
    };

// 延迟函数
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
app.use(express.json());
// 旧
app.get('/api/sign/:id', async (req, res) => {
    // 获取参数
    let id = req.params.id;
    // 初始化
    var antiSign = new (g);
    antiSign.init("000003df64d39f9630e91a5d72fbcd5652714a5198eb9dbea1a8b15e6b92342c");
    // 延迟1ms
    await delay(1);
    // 计算签名
    var signArr = antiSign.sign(id);
    var signStr = uint8ArrayToHex(signArr);
    res.end(signStr);
});

// 新
app.get('/api/sign_v1', async (req, res) => {
    // 获取参数
    const id = req.query.id;
    const key = req.query.key;
    // 初始化
    var antiSign = new (g);
    antiSign.init(key);
    // 延迟1ms
    await delay(1);
    // 计算签名
    var signArr = antiSign.sign(id);
    var signStr = uint8ArrayToHex(signArr);
    res.end(signStr);
});
// 新
app.post('/gorgon', async (req, res) => {
    // 获取参数
    let { input, key } = req.body;
    // 初始化
    var antiSign = new (g);
    antiSign.init(key);
    // 延迟1ms
    await delay(1);
    // 计算签名
    var signArr = antiSign.sign(input);
    var signStr = uint8ArrayToHex(signArr);
    res.json({
        "x-gorgon": signStr
    });
});

const port = 3000; // 你可以根据需要选择端口号

// 启动服务器
app.listen(port, "0.0.0.0", () => {
    console.log(`Server is running on http://localhost:${port}`);
});

